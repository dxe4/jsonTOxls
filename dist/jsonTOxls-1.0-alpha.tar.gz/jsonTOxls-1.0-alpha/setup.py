from distutils.core import setup

setup(
    name='jsonTOxls',
    version='1.0-alpha',
    packages=['examples'],
    license='GPL',
    long_description=open('README.md').read(),

)
