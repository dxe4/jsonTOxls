from distutils.core import setup

setup(
    name='jsonTOxls',
    version='1.0-alpha',
    packages=['client','server','client/examples','common'],
    license='GPL',
    long_description=open('README.md').read(),

)
